# Windows 10
W10  Digital License Activation Script
